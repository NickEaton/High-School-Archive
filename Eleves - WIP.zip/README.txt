Project is currently a work in progress, when completed will feature a full GUI display and user interaction
through the GUI, all console interaction is reserved for debugging